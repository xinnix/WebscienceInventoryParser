# WebscienceInventoryParser
For gege
# Reference
  * https://github.com/nickewing/line-reader
  * https://github.com/nwjs/nw.js
  * https://github.com/imoldman/nw-file-explorer
  * https://github.com/functionscope/Node-Excel-Export
